# О Haskell по-человечески

Книга о прекрасном и удивительном языке программирования Haskell. Для обыкновенных программистов.

Создана с помощью блистательных [Hakyll](http://jaspervdj.be/hakyll/) и [Materialize](http://materializecss.com/).
