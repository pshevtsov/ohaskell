# О Haskell по-человечески

Книга о прекрасном и удивительном языке программирования Haskell. Для обыкновенных программистов.

Вы можете читать книгу [онлайн](http://ohaskell.dshevchenko.biz/) или скачать [локальную html-версию](https://github.com/denisshevchenko/ohaskell/blob/gh-pages/ohaskell.zip?raw=true) (можно читать без подключения к интернету).

Создана с помощью блистательных [Hakyll](http://jaspervdj.be/hakyll/) и [Materialize](http://materializecss.com/).
